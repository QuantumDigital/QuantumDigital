IMCE Search provides a search tab for the IMCE file manager which
allows users to search for files listed in the files table. To use
enable the module, no configuration is necessary.
